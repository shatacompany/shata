---
layout: inner
position: right
title: 'Bloc Jams Angular'
date: 2016-02-20 14:15:00
categories: development
tags: JavaScript AngularJS Sass Grunt
featured_image: '/img/posts/01_bloc-jams-angular-1130x864-2x.png'
project_link: 'https://github.com/jamigibbs/bloc-jams-angular'
button_icon: 'github'
button_text: 'Visit Project'
lead_text: 'A digital music player built using AngularJS'
---
