---
layout: inner
position: left
title: 'Phantom'
date: 2016-02-20 21:15:00
categories: development design
tags: Jekyll Sass Bootstrap
featured_image: '/img/posts/04_phantom-jekyll-1130x864-2x.png'
project_link: 'https://github.com/jamigibbs'
button_icon: 'flask'
button_text: 'Visit Project'
lead_text: "A minimalist Jekyll theme that you're looking at it right now"
---
